import java.util.Vector;

/**
 * Created by octavian.guzu on 2/23/2017.
 */
public class DataCenter {
    Vector<Video> videos = new Vector<>();

    public void addVideo(Video v) {
        videos.add(v);
    }
}
